# CM124-224FinalProject
## Language: Python 2
# To Run
## python predict_haplotype.py [masked input data file] [output data file]
## Please put [masked input data file] at same directory with predict_haplotype.py
## It has to have 3 arguments
## For  example:
## python predict_haplotype.py test_data_masked.txt test_data_sol.txt